-- Item data (c) Grinding Gear Games

return {
-- Body: Armour
[[
Blackbraid
Fur Plate
Variant: Pre 0.1.1
Variant: Current
{variant:2}+(40-60) to Armour
+(5-15) to Strength
+(5-15) to Intelligence
{variant:2}+10% to all Elemental Resistances
+(40-60) to Stun Threshold
Armour applies to Elemental Damage
]],[[
Bramblejack
Rusted Cuirass
Variant: Pre 0.1.1
Variant: Current
{variant:1}+(50-80) to maximum Life
{variant:2}+(60-100) to maximum Life
+(60-100) to Stun Threshold
{variant:2}Cannot Evade Enemy Attacks
250% of Melee Physical Damage taken reflected to Attacker
{variant:2}Regenerate 5% of maximum Life per second while Surrounded
]],[[
The Brass Dome
Champion Cuirass
Variant: Pre 0.1.1
Variant: Current
{variant:1}(300-400)% increased Armour
{variant:2}(400-500)% increased Armour
{variant:1}+5% to all Maximum Elemental Resistances
{variant:2}-(5-1)% to all Maximum Elemental Resistances
+(200-300) to Stun Threshold
Take no Extra Damage from Critical Hits
]],[[
Edyrn's Tusks
Iron Cuirass
Variant: Pre 0.1.1
Variant: Current
(120-160)% increased Armour
{variant:1}10% chance to inflict Bleeding on Hit
{variant:2}50% chance to inflict Bleeding on Hit
50% reduced Slowing Potency of Debuffs on You
(15-20) to (25-30) Physical Thorns damage
]],[[
Greed's Embrace
Vaal Cuirass
50% increased Strength Requirement
20% reduced Movement Speed
(100-150)% increased Armour
(30-50)% increased Rarity of Items found
+(20-30)% to Fire Resistance
]],[[
The Road Warrior
Raider Plate
Variant: Pre 0.1.1
Variant: Current
{variant:1}(50-100)% increased Armour
{variant:2}+(10-15) to all Attributes
{variant:1}+(15-25)% to Fire Resistance
{variant:2}+(15-30)% to Fire Resistance
{variant:1}+(15-25)% to Lightning Resistance
{variant:2}+(15-30)% to Lightning Resistance
{variant:2}(10-15) Life Regeneration per second
Moving while Bleeding doesn't cause you to take extra damage
]],[[
Kaom's Heart
Conqueror Plate
Implicits: 1
(30-40)% increased Stun Threshold
+1000 to maximum Life
You have no Spirit
]],[[
Kingsguard
Full Plate
+(60-80) to maximum Life
+(40-60) to maximum Mana
+(5-10)% to all Elemental Resistances
25% reduced Endurance Charge Duration
Recover 5% of maximum Life for each Endurance Charge consumed
]],[[
Titanrot Cataphract
Maraketh Cuirass
Variant: Pre 0.1.1
Variant: Current
{variant:1}(200-300)% increased Armour
{variant:2}(400-500)% increased Armour
{variant:1}(10-20)% increased Strength
{variant:2}(15-30)% increased Strength
10% reduced Dexterity
10% reduced Intelligence
You have no Life Regeneration
]],[[
Wandering Reliquary
Steel Plate
Variant: Pre 0.1.1
Variant: Current
(50-100)% increased Armour
+(40-60) to maximum Mana
+(10-20) to Strength
{variant:2}+(60-80) to Stun Threshold
50% of Physical Damage prevented Recouped as Life
]],
-- Body: Evasion
[[
Ashrend
Pathfinder Coat
Variant: Pre 0.1.1
Variant: Current
+(40-60) to maximum Life
{variant:2}+(10-20) to Strength
{variant:1}+(20-30)% to Fire Resistance
{variant:2}+(30-40)% to Fire Resistance
Cannot be Ignited
-10 Physical Damage taken from Attack Hits
]],[[
Briskwrap
Rhoahide Coat
Variant: Pre 0.1.1
Variant: Current
{variant:2}(60-100)% increased Evasion Rating
(40-60)% increased Flask Life Recovery rate
(40-60)% increased Flask Mana Recovery rate
+(20-30) to Dexterity
+(20-30)% to Cold Resistance
]],[[
Bristleboar
Leather Vest
Variant: Pre 0.1.1
Variant: Current
{variant:1}(40-80)% increased Evasion Rating
{variant:2}50% reduced Evasion Rating
+(40-60) to maximum Life
{variant:2}(3-5) Life Regeneration per second
{variant:1}Gain 3 Rage when Hit by an Enemy
{variant:2}Gain 5 Rage when Hit by an Enemy
Gain 10 Rage when Critically Hit by an Enemy
]],[[
Dustbloom
Studded Vest
(100-150)% increased Evasion Rating
+(20-30)% to Cold Resistance
Maximum 10 Fragile Regrowth
0.5% of maximum Life Regenerated per second per Fragile Regrowth
10% increased Mana Regeneration Rate per Fragile Regrowth
Lose all Fragile Regrowth when Hit
Gain 1 Fragile Regrowth each second
]],[[
Foxshade
Quilted Vest
+(50-70) to Evasion Rating
+(20-30) to Dexterity
10% increased Movement Speed when on Full Life
100% increased Evasion Rating when on Full Life
]],[[
Hyrri's Ire
Armoured Vest
Implicits: 1
(30-40)% increased Elemental Ailment Threshold
(100-130)% increased Evasion Rating
Adds (13-20) to (21-31) Cold damage to Attacks
+(30-40) to Dexterity
25% increased Chill Duration on Enemies
Can Evade all Hits if you have not been Hit Recently
]],[[
Quatl's Molt
Serpentscale Coat
Variant: Pre 0.1.1
Variant: Current
{variant:2}(60-80)% increased Evasion Rating
{variant:1}+(30-50) to maximum Life
{variant:2}+(60-80) to maximum Life
+(17-23)% to Chaos Resistance
(10-20) Life Regeneration per second
Cannot be Poisoned
]],[[
Queen of the Forest
Smuggler Coat
Variant: Pre 0.2.0
Variant: Current
(100-150)% increased Evasion Rating
-(15-10)% to Fire Resistance
+(25-30)% to Cold Resistance
+(10-15)% to Lightning Resistance
{variant:1}1% increased Movement Speed per 500 Evasion Rating
{variant:2}1% increased Movement Speed per 800 Evasion Rating
{variant:1}Other Modifiers to Movement Speed do not apply
{variant:2}Other Modifiers to Movement Speed do not apply
]],[[
The Rat Cage
Scout's Vest
(100-150)% increased Evasion Rating
+300 to maximum Life
25% reduced Attribute Requirements
100% of Fire Damage from Hits taken as Physical Damage
]],[[
Sands of Silk
Shrouded Vest
(50-100)% increased Evasion Rating
+(50-80) to maximum Mana
+(10-20) to Dexterity
+(10-20) to Intelligence
+(10-15)% to Fire Resistance
(15-30)% increased Cooldown Recovery Rate
]],[[
Yriel's Fostering
Strider Vest
(100-150)% increased Evasion Rating
+(80-120) to maximum Life
+(10-30) to Spirit
(40-60)% reduced Bleeding Duration on you
(40-60)% reduced Poison Duration on you
You can have two Companions of different types
]],

-- Body: Energy Shield
[[
Bitterbloom
Feathered Robe
(50-100)% increased Energy Shield
+(50-100) to maximum Mana
50% increased Energy Shield Recharge Rate
Energy Shield Recharge starts when you use a Mana Flask
]],[[
The Black Doubt
Hexer's Robe
Variant: Pre 0.1.1
Variant: Current
(60-100)% increased Energy Shield
+(10-30) to Intelligence
{variant:2}+(10-20)% to Cold Resistance
Damage over Time bypasses your Energy Shield
While not on Full Life, Sacrifice 10% of maximum Mana per Second to Recover that much Life
]],[[
Cloak of Defiance
Havoc Raiment
(50-100)% increased Energy Shield
+(100-150) to maximum Mana
50% increased Mana Regeneration Rate
30% of Damage is taken from Mana before Life
]],[[
Cloak of Flame
Silk Robe
+(30-50)% to Fire Resistance
(30-50)% reduced Ignite Duration on you
40% of Physical Damage taken as Fire Damage
25 to 35 Fire Thorns damage
]],[[
The Covenant
Altar Robe
(100-150)% increased Energy Shield
+(100-150) to maximum Life
5% of Spell Damage Leeched as Life
Skills gain a Base Life Cost equal to 50% of Base Mana Cost
]],[[
Ghostwrithe
Tattered Robe
Variant: Pre 0.2.0
Variant: Current
+100 to maximum Energy Shield
+(29-37)% to Chaos Resistance
{variant:1}50% of Maximum Life Converted to Energy Shield
{variant:2}25% of Maximum Life Converted to Energy Shield
]],[[
Gloamgown
Elementalist Robe
(100-140)% increased Energy Shield
+(30-40) to Spirit
+(25-35)% to Cold Resistance
1000% increased Energy Shield Recharge Rate
Your base Energy Shield Recharge Delay is 10 seconds
]],[[
Necromantle
Bone Raiment
Variant: Pre 0.1.1
Variant: Current
+(40-60) to maximum Life
+(30-50) to maximum Mana
{variant:2}Minions have +(17-23)% to Chaos Resistance
Minions gain (20-30)% of their maximum Life as Extra maximum Energy Shield
Minions Revive 50% faster
]],[[
Prayers for Rain
Keth Raiment
Variant: Pre 0.1.1
Variant: Current
(60-100)% increased Energy Shield
+(10-15) to Intelligence
{variant:2}+(10-20)% to Lightning Resistance
30% slower start of Energy Shield Recharge
Energy Shield Recharge is not interrupted by Damage if Recharge began Recently
]],[[
Silks of Veneration
Havoc Raiment
Implicits: 1
(40-50)% increased Mana Regeneration Rate
+(30-50) to Spirit
+(20-30) to Intelligence
+(10-20)% to all Elemental Resistances
(30-50)% increased Energy Shield Recharge Rate
Current Energy Shield also grants Elemental Damage reduction
]],[[
Temporalis
Silk Robe
Variant: Pre 0.2.0
Variant: Current
+(100-150) to maximum Energy Shield
+(10-20)% to all Elemental Resistances
(5-30)% of Damage taken Recouped as Life
(5-30)% of Damage taken Recouped as Mana
{variant:1}Skills have -(4-2) seconds to Cooldown
{variant:2}Skills have -(2-1) seconds to Cooldown
]],[[
Tetzlapokal's Desire
Votive Raiment
Variant: Pre 0.1.1
Variant: Current
(100-150)% increased Energy Shield
+(20-30) to Strength
{variant:2}+(20-30) to Intelligence
+(17-23)% to Chaos Resistance
Life Recharges
]],[[
Vis Mortis
Plated Raiment
(70-100)% increased Energy Shield
+(70-100) to maximum Mana
Minions have 50% reduced maximum Life
Minions have Unholy Might
]],
-- Body: Armour/Evasion
[[
The Barrow Dweller
Rogue Armour
Variant: Pre 0.1.1
Variant: Current
(60-100)% increased Armour and Evasion
-(20-10)% to Fire Resistance
+50% to Cold Resistance
{variant:2}Damage of Enemies Hitting you is Unlucky while you are on Low Life
50% chance to Avoid Death from Hits
]],[[
Belly of the Beast
Explorer Armour
Variant: Pre 0.1.1
Variant: Current
(100-150)% increased Armour and Evasion
+(100-150) to maximum Life
+(100-150) to Stun Threshold
Life Recovery from Flasks is instant
{variant:2}(25-30) to (35-40) Physical Thorns damage
]],[[
Coat of Red
Chain Mail
(80-100)% increased Armour and Evasion
+(80-100) to maximum Life
+(75-150) to Stun Threshold
25% chance to be inflicted with Bleeding when Hit
]],[[
The Coming Calamity
Heroic Armour
Implicits: 4
Grants Skill: Level (1-20) Herald of Ash
Grants Skill: Level (1-20) Herald of Ice
Grants Skill: Level (1-20) Herald of Thunder
+(60-80) to maximum Life
+(30-40)% to all Elemental Resistances
Enemies in your Presence have no Elemental Resistances
]],[[
Doryani's Prototype
Scale Mail
(50-100)% increased Armour and Evasion
+(60-80) to maximum Life
Armour also applies to Lightning damage taken from Hits
Enemies in your Presence have Lightning Resistance equal to yours
Lightning Resistance does not affect Lightning damage taken
]],[[
The Fallen Formation
Lamellar Mail
(100-200)% increased Armour and Evasion
+(20-30) to Strength
+(20-30) to Dexterity
(8-12) Life Regeneration per second
-20 to maximum Valour
Banners always have maximum Valour
]],[[
Irongrasp
Vagabond Armour
Variant: Pre 0.1.1
Variant: Current
(100-150)% increased Armour and Evasion
{variant:2}+(20-30) to Strength
+(100-150) to Stun Threshold
Iron Grip
Iron Will
]],[[
Pariah's Embrace
Cloaked Mail
Variant: Pre 0.1.1
Variant: Current
(50-80)% increased Armour and Evasion
+50 to Spirit
{variant:2}+(10-15) to all Attributes
(10-15) Life Regeneration per second
20% reduced Mana Cost of Skills
]],[[
Perfidy
Knight Armour
Source: Drops from unique{Kosis, The Revelation}
(100-150)% increased Armour and Evasion
(10-40)% chance to Avoid Physical Damage from Hits
(10-40)% chance to Avoid Chaos Damage from Hits
Enemies in your Presence are Intimidated
]],[[
Pragmatism
Explorer Armour
Source: Drops from unique{The King in the Mists} in normal{Crux of Nothingness}
(200-300)% increased Armour and Evasion
+(10-20)% to all Elemental Resistances
-17% to Chaos Resistance
Charms use no Charges
]],[[
Widow's Reign
Knight Armour
(100-150)% increased Armour and Evasion
+(100-150) to maximum Life
+(17-23)% to Chaos Resistance
+(200-300) to Ailment Threshold
Life that would be lost by taking Damage is instead Reserved
until you take no Damage to Life for 5 seconds
]],
-- Body: Armour/Energy Shield
[[
Couture of Crimson
Gilded Vestments
(50-100)% increased Armour and Energy Shield
25% reduced maximum Life
(40-60)% reduced Bleeding Duration on you
Life Leech can Overflow Maximum Life
]],[[
Enfolding Dawn
Pilgrim Vestments
(50-100)% increased Armour and Energy Shield
+100 to Spirit
+(5-15)% to all Elemental Resistances
Gain no inherent bonus from Intelligence
]],[[
Husk of Dreams
Shaman Mantle
Variant: Pre 0.1.1
Variant: Current
(100-150)% increased Armour and Energy Shield
-10% to Fire Resistance
{variant:1}+(13-17)% to Chaos Resistance
{variant:2}+(13-17)% to Chaos Resistance
{variant:1}(25-50)% increased Flask Charges used
{variant:2}(20-30)% increased Flask Charges used
50% chance for Flasks you use to not consume Charges
]],[[
Icetomb
Mail Vestments
+(20-30) to Strength
+(20-30) to Intelligence
+(30-40)% to Cold Resistance
Freeze as though dealing Cold damage equal to 10% of your maximum Mana when Hit
]],[[
The Mutable Star
Cleric Vestments
(100-150)% increased Armour and Energy Shield
(50-100)% increased Energy Shield Recharge Rate
(25-35) Life Regeneration per second
(30-50)% reduced Bleeding Duration on you
(30-50)% reduced Ignite Duration on you
Defend against Hits as though you had 1% more Armour per 1% current Energy Shield
]],[[
Sacrosanctum
Corvus Mantle
Implicits: 1
+(20-30) to Spirit
(80-120)% increased Armour and Energy Shield
+(20-30) to Strength
+(20-30) to Intelligence
+(17-23)% to Chaos Resistance
(5-10)% of Damage taken Recouped as Life
Damage taken Recouped as Life is also Recouped as Energy Shield
]],[[
Soul Mantle
Sacrificial Mantle
(80-120)% increased Armour and Energy Shield
+10 to Strength
+15 to Intelligence
(20-30)% reduced Totem Life
+1 to maximum number of Summoned Totems
Inflicts a random Curse on you when your Totems die, ignoring Curse limit
]],[[
Voll's Protector
Ironclad Vestments
Variant: Pre 0.1.1
Variant: Current
(100-150)% increased Armour and Energy Shield
25% reduced maximum Mana
{variant:2}+(13-17)% to Chaos Resistance
25% chance to gain a Power Charge on Critical Hit
]],[[
Waveshaper
Tideseer Mantle
+(100-200) to maximum Energy Shield
+(20-40) to Spirit
+(25-35)% to Fire Resistance
+(25-35)% to Cold Resistance
Increases and Reductions to Mana Regeneration Rate also
apply to Energy Shield Recharge Rate
Gain (30-50)% of Maximum Mana as Armour
]],
-- Body: Evasion/Energy Shield
[[
Apron of Emiran
Hermit Garb
(30-50)% increased Evasion and Energy Shield
+(10-20) to Dexterity
(40-60)% reduced Bleeding Duration on you
Bleeding you inflict is Aggravated
]],[[
The Dancing Mirage
Wayfarer Jacket
Variant: Pre 0.1.1
Variant: Current
{variant:1}(60-100)% increased Evasion and Energy Shield
{variant:2}(150-200)% increased Evasion and Energy Shield
+(10-20)% to Lightning Resistance
20% less Damage taken if you have not been Hit Recently
100% increased Evasion Rating if you have been Hit Recently
]],[[
Gloomform
Waxed Jacket
Variant: Pre 0.1.1
Variant: Current
(100-150)% increased Evasion Rating
+(10-20) to Dexterity
{variant:2}+(10-20)% to Fire Resistance
20% reduced Light Radius
You have a Smoke Cloud around you while stationary
]],[[
Redflare Conduit
Anchorite Garb
Variant: Pre 0.1.1
Variant: Current
+(50-70) to maximum Mana
{variant:2}-15% to Cold Resistance
{variant:1}+(20-30)% to Lightning Resistance
{variant:2}+(30-40)% to Lightning Resistance
20% chance to gain a Power Charge on Hit
Lose all Power Charges on reaching maximum Power Charges
Shocks you when you reach maximum Power Charges
]],[[
Sierran Inheritance
Marabout Garb
(50-80)% increased Evasion and Energy Shield
+(15-25)% to Lightning Resistance
(30-50)% faster start of Energy Shield Recharge
The Effect of Chill on you is reversed
]],[[
Zerphi's Serape
Scalper's Jacket
(60-80)% increased Evasion and Energy Shield
+(40-60) to maximum Mana
50% increased Attribute Requirements
(-30-30)% reduced Life Regeneration rate
(-30-30)% reduced Mana Regeneration Rate
Soul Eater
]],
-- Body: Armour/Evasion/Energy Shield
[[
Morior Invictus
Grand Regalia
Has Alt Variant: true
Has Alt Variant Two: true
Source: Drops from unique{Arbiter of Ash} in normal{The Burning Monolith}
Selected Variant: 2
Selected Alt Variant: 4
Selected Alt Variant Two: 6
Variant: Spirit (Pre 0.2.0)
Variant: Spirit
Variant: Life (Pre 0.2.0)
Variant: Life
Variant: Mana (Pre 0.2.0)
Variant: Mana
Variant: Global Defences (Pre 0.2.0)
Variant: Global Defences
Variant: Item Rarity (Pre 0.2.0)
Variant: All Resistances (Pre 0.2.0)
Variant: All Resistances
Variant: Attributes (Pre 0.2.0)
Variant: Attributes
Variant: Chaos Resistance
Variant: Stun Threshold
Variant: Life Regeneration
Variant: Reduced Crit Damage
Sockets: S S S S
(200-300)% increased Armour, Evasion and Energy Shield
{variant:13}+(4-6) to all Attributes per Socket filled
{variant:12}5% increased Attributes per Socket filled
{variant:14}+(7-10)% to Chaos Resistance per Socket filled
{variant:16}(4-6) Life Regeneration per second per Socket filled
{variant:4}+(25-40) to maximum Life per Socket filled
{variant:6}+(20-30) to maximum Mana per Socket filled
{variant:17}Hits against you have (10-15)% reduced Critical Damage Bonus per Socket filled
{variant:7}10% increased Global Defences per Socket filled
{variant:8}(6-10)% increased Global Defences per Socket filled
{variant:9}10% increased Rarity of Items found per Socket filled
{variant:3}5% increased Maximum Life per Socket filled
{variant:5}5% increased Maximum Mana per Socket filled
{variant:10}+10% to all Elemental Resistances per Socket filled
{variant:11}+(5-7)% to all Elemental Resistances per Socket filled
{variant:1}+10 to Spirit per Socket filled
{variant:2}+(6-10) to Spirit per Socket filled
{variant:15}+(40-60) to Stun Threshold per Socket filled
]],[[
Skin of the Loyal
Garment
Source: Drops from unique{Xesht, We That Are One} in normal{Twisted Domain}
+(5-40)% to all Elemental Resistances
Elemental Ailment Threshold is increased by Overcapped Chaos Resistance
Armour is increased by Overcapped Fire Resistance
Energy Shield is increased by Overcapped Cold Resistance
Evasion Rating is increased by Overcapped Lightning Resistance
]],[[
Tabula Rasa
Garment
Sockets: S S S S S S
Has 6 Rune Sockets
]],
}
